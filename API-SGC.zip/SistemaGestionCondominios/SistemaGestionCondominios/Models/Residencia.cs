﻿namespace SistemaGestionCondominios.Models
{
    public class Residencia
    {
        public int Id { get; set; }
        public string Numero { get; set; }
        public string Direccion { get; set; }
        //public int UsuarioId { get; set; }
    }
}
