﻿namespace SistemaGestionCondominios.Utils
{
    public static class Roles
    {
        public const string Administrador = "Administrador";
    }
}
