﻿namespace SistemaGestionCondominios.DTOs.Encuesta
{
    public class EncuestaPostDto
    {
        public string Titulo { get; set; }
        public string Descripcion { get; set; }
    }
}
