﻿namespace SistemaGestionCondominios.DTOs.Notificacion
{
    public class NotificacionPostDto
    {
        public string Mensaje { get; set; }
        public bool Leido { get; set; }
        //public int UsuarioId { get; set; }
    }
}
