﻿namespace SistemaGestionCondominios.DTOs.Residencia
{
    public class ResidenciaPostDto
    {
        public string Numero { get; set; }
        public string Direccion { get; set; }
        //public int UsuarioId { get; set; }
    }
}
