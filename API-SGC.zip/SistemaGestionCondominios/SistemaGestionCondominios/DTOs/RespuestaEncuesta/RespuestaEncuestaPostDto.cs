﻿namespace SistemaGestionCondominios.DTOs.RespuestaEncuesta
{
    public class RespuestaEncuestaPostDto
    {
        public string Respuesta { get; set; }
        public int EncuestaId { get; set; }
        //public int UsuarioId { get; set; }
    }
}
